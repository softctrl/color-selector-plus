package template.tool;

import java.applet.Applet;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

import processing.app.Base;

import java.awt.image.BufferedImage;

public class ColorSelector extends JFrame implements KeyListener,WindowFocusListener {

	private JPanel contentPane;
	private JTextField txtcolorValue;
	private ZoomScreen zoomScreen;
	private JSlider zoomSlider;
	private JPanel selectedColor;
	private JLabel lblHex;
	private JLabel lblMsg;
	private JTextField txtB;
	private JLabel lblGreen;
	private JTextField txtG;
	private JLabel label_2;
	private JTextField txtR;
	private JLabel lblHue;
	private JTextField txtH;
	private JLabel lblSat;
	private JTextField txtS;
	private JLabel lblVal;
	private JTextField txtV;
	private JLabel lblBlue;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ColorSelector frame = new ColorSelector();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ColorSelector() {
		Base.setIcon(this);
		setResizable(false);
		setTitle("Color Selector++");
		addWindowFocusListener(this);
		setAlwaysOnTop(true);

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Unable to load Windows look and feel");
		}

		addKeyListener(this);
		addWindowFocusListener(this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 334, 498);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel zoomPanel = new JPanel();
		zoomPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		zoomPanel.setFocusTraversalKeysEnabled(false);
		zoomPanel.setFocusable(false);
		zoomPanel.setLayout(new BorderLayout());
		zoomScreen = new ZoomScreen();
		zoomScreen.init();
		zoomPanel.setBounds(14, 11, 300, 300);
		zoomPanel.add(zoomScreen, BorderLayout.CENTER);
		zoomPanel.addKeyListener(this);
		contentPane.add(zoomPanel);

		txtcolorValue = new JTextField();
		txtcolorValue.setFocusTraversalKeysEnabled(false);
		txtcolorValue.setEditable(false);
		txtcolorValue.setBounds(172, 441, 60, 20);
		contentPane.add(txtcolorValue);
		txtcolorValue.setColumns(10);
		txtcolorValue.addKeyListener(this);
		zoomSlider = new JSlider();
		zoomSlider.setFocusable(false);
		zoomSlider.setFocusTraversalKeysEnabled(false);
		zoomSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				zoomScreen.zoomLevel = zoomSlider.getMaximum() + 5
						- zoomSlider.getValue();
			}
		});
		zoomSlider.setPaintTicks(true);
		zoomSlider.setMinorTickSpacing(10);
		zoomSlider.setMajorTickSpacing(10);
		zoomSlider.setMinimum(5);
		zoomSlider.setMaximum(95);
		zoomSlider.setSnapToTicks(true);
		zoomSlider.setBounds(95, 343, 182, 29);
		contentPane.add(zoomSlider);

		JLabel lblNewLabel = new JLabel("Zoom");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(53, 343, 46, 29);
		contentPane.add(lblNewLabel);

		lblMsg = new JLabel(
				"Press Spacebar to grab a Color and copy its hex to Clipboard");
		lblMsg.setHorizontalAlignment(SwingConstants.CENTER);
		lblMsg.setBounds(14, 320, 300, 14);
		contentPane.add(lblMsg);

		selectedColor = new JPanel();
		selectedColor.setBorder(new LineBorder(new Color(0, 0, 0)));
		selectedColor.setBackground(SystemColor.control);
		selectedColor.setBounds(242, 383, 78, 78);
		selectedColor.addKeyListener(this);
		contentPane.add(selectedColor);
		
		lblHex = new JLabel("Hex");
		lblHex.setHorizontalAlignment(SwingConstants.CENTER);
		lblHex.setBounds(128, 444, 46, 14);
		contentPane.add(lblHex);
		
		txtB = new JTextField();
		txtB.setHorizontalAlignment(SwingConstants.RIGHT);
		txtB.setFocusTraversalKeysEnabled(false);
		txtB.setEditable(false);
		txtB.setColumns(10);
		txtB.setBounds(200, 384, 33, 20);
		txtB.addKeyListener(this);
		contentPane.add(txtB);
		
		lblGreen = new JLabel("Green");
		lblGreen.setFocusable(false);
		lblGreen.setFocusTraversalKeysEnabled(false);
		lblGreen.setHorizontalAlignment(SwingConstants.CENTER);
		lblGreen.setBounds(84, 386, 46, 14);
		contentPane.add(lblGreen);
		
		txtG = new JTextField();
		txtG.setHorizontalAlignment(SwingConstants.RIGHT);
		txtG.setFocusTraversalKeysEnabled(false);
		txtG.setEditable(false);
		txtG.setColumns(10);
		txtG.setBounds(128, 383, 33, 20);
		txtG.addKeyListener(this);
		contentPane.add(txtG);
		
		label_2 = new JLabel("Red");
		label_2.setFocusable(false);
		label_2.setFocusTraversalKeysEnabled(false);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(10, 387, 46, 14);
		contentPane.add(label_2);
		
		txtR = new JTextField();
		txtR.setHorizontalAlignment(SwingConstants.RIGHT);
		txtR.setFocusTraversalKeysEnabled(false);
		txtR.setEditable(false);
		txtR.setColumns(10);
		txtR.setBounds(54, 384, 33, 20);
		txtR.addKeyListener(this);
		contentPane.add(txtR);
		
		lblHue = new JLabel("Hue");
		lblHue.setFocusable(false);
		lblHue.setFocusTraversalKeysEnabled(false);
		lblHue.setHorizontalAlignment(SwingConstants.CENTER);
		lblHue.setBounds(10, 416, 46, 14);
		contentPane.add(lblHue);
		
		txtH = new JTextField();
		txtH.setHorizontalAlignment(SwingConstants.RIGHT);
		txtH.setFocusTraversalKeysEnabled(false);
		txtH.setEditable(false);
		txtH.setColumns(10);
		txtH.setBounds(54, 413, 33, 20);
		txtH.addKeyListener(this);
		contentPane.add(txtH);
		
		lblSat = new JLabel("Sat");
		lblSat.setFocusable(false);
		lblSat.setFocusTraversalKeysEnabled(false);
		lblSat.setHorizontalAlignment(SwingConstants.CENTER);
		lblSat.setBounds(84, 415, 46, 14);
		contentPane.add(lblSat);
		
		txtS = new JTextField();
		txtS.setHorizontalAlignment(SwingConstants.RIGHT);
		txtS.setFocusTraversalKeysEnabled(false);
		txtS.setEditable(false);
		txtS.setColumns(10);
		txtS.setBounds(128, 412, 33, 20);
		txtS.addKeyListener(this);
		contentPane.add(txtS);
		
		lblVal = new JLabel("Val");
		lblVal.setFocusable(false);
		lblVal.setFocusTraversalKeysEnabled(false);
		lblVal.setHorizontalAlignment(SwingConstants.CENTER);
		lblVal.setBounds(156, 416, 46, 14);
		contentPane.add(lblVal);
		
		txtV = new JTextField();
		txtV.setHorizontalAlignment(SwingConstants.RIGHT);
		txtV.setFocusTraversalKeysEnabled(false);
		txtV.setEditable(false);
		txtV.setColumns(10);
		txtV.setBounds(200, 413, 33, 20);
		txtV.addKeyListener(this);
		contentPane.add(txtV);
		
		lblBlue = new JLabel("Blue");
		lblBlue.setHorizontalAlignment(SwingConstants.CENTER);
		lblBlue.setFocusable(false);
		lblBlue.setFocusTraversalKeysEnabled(false);
		lblBlue.setBounds(156, 387, 46, 14);
		
		setColorValue(zoomScreen.pointColor);
		contentPane.add(lblBlue);
	}

	public void grabColor() {
		selectedColor.setBackground(zoomScreen.pointColor);
		setColorValue(zoomScreen.pointColor);
		
		copyToClipboard(txtcolorValue.getText());
	}
	
	void copyToClipboard(String s) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		Transferable text = new StringSelection(s);
		clipboard.setContents(text, null);
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == e.VK_SPACE) {
			grabColor();			
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public void setColorValue(Color pointColor) {
		txtcolorValue.setText("#"+Integer.toHexString(pointColor.getRGB()).substring(2).toUpperCase());
		txtR.setText(pointColor.getRed()+"");
		txtG.setText(pointColor.getGreen()+"");
		txtB.setText(pointColor.getBlue()+"");
		float hsb[] = Color.RGBtoHSB(pointColor.getRed(), pointColor.getGreen(), pointColor.getBlue(),null);
		txtH.setText((int)(hsb[0]*360)+"");
		txtS.setText((int)(hsb[1]*255)+"");
		txtV.setText((int)(hsb[2]*255)+"");
	} 

	private class ZoomScreen extends Applet implements Runnable, KeyListener{

		public int imgWidth = 300;
		public int imgHeight = 300;
		private ZoomPanel zoomPanel;
		private JPanel parentPanel;

		public void init() {
			mouseC = mouseP = MouseInfo.getPointerInfo().getLocation();
			parentPanel = new JPanel();
			zoomPanel = new ZoomPanel();
			setLayout(new BorderLayout());
			parentPanel.setLayout(new BorderLayout());
			parentPanel.add(zoomPanel, BorderLayout.CENTER);
			add(parentPanel);
			try {
				robot = new Robot(gs[0]);
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Thread th = new Thread(this);
			th.start();
			addKeyListener(this);
		}

		public int zoomLevel = 25; // 15 to 55, with steps of 10
		private GraphicsEnvironment ge = GraphicsEnvironment
				.getLocalGraphicsEnvironment();
		private GraphicsDevice[] gs = ge.getScreenDevices();
		private Rectangle bounds;
		private BufferedImage desktop = new BufferedImage(zoomLevel, zoomLevel,
				BufferedImage.TYPE_INT_RGB);
		private BufferedImage resizedImage;
		private Robot robot;

		private BufferedImage getScreen() {

			// zoomLevel = 12;

			bounds = new Rectangle(mouseC.x - zoomLevel / 2, mouseC.y
					- zoomLevel / 2, zoomLevel, zoomLevel);
			desktop = new BufferedImage(zoomLevel, zoomLevel,
					BufferedImage.TYPE_INT_RGB);

			desktop = robot.createScreenCapture(bounds);
			resizedImage = new BufferedImage(imgWidth, imgHeight,
					BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(desktop, 0, 0, imgWidth, imgHeight, null);
			g.dispose();
			return resizedImage;
		}

		private int zm;
		private Point mouseC, mouseP;

		public void run() {
			while (true) {
				mouseC = MouseInfo.getPointerInfo().getLocation();
				if (!mouseC.equals(mouseP)) {
					zoomPanel.repaint();
					mouseP = mouseC;
				}

			}
		}

		public Color pointColor = (Color.LIGHT_GRAY);
		public BufferedImage screen;

		private class ZoomPanel extends JPanel {
			// private BufferedImage image;

			@Override
			public void paintComponent(Graphics g) {
				// g.drawImage(image, 0, 0, null);
				zm = imgHeight / zoomLevel;
				screen = getScreen();
				g.drawImage(screen, 0, 0, this);
				g.setColor(Color.black);
				g.drawRect(imgWidth / 2 - zm / 2, imgHeight / 2 - zm / 2, zm,
						zm);
				pointColor = new Color(screen.getRGB(imgWidth / 2 + 1,
						imgHeight / 2));
				
			}
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			if (e.getKeyCode() == e.VK_SPACE) {
				selectedColor.setBackground(zoomScreen.pointColor);
				setColorValue(pointColor);
			}
		}

		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
			 
		}

		@Override
		public void keyTyped(KeyEvent arg0) {
			// TODO Auto-generated method stub
			
		}

	}

	public void windowGainedFocus(WindowEvent arg0) {
		lblMsg.setText("Press Spacebar to grab a Color and copy its hex to Clipboard");
	}
	public void windowLostFocus(WindowEvent arg0) {
		lblMsg.setText("Click on the Color Selector window to start grabbing a Color");
	}
}
